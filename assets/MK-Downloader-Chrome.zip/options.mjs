import { DEFAULT_SETTINGS, cleanSettings, permissionOrigin } from './core.mjs';
import { decorate, send, message } from './ui.mjs';
decorate();
const $ = id => document.getElementById(id);
let saved = cleanSettings({ ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get('settings')).settings });
$('engine-url').value = saved.engineUrl; $('token').value = saved.token;
$('context-menu').checked = saved.contextMenu; $('auto-capture').checked = saved.autoCapture; $('notifications').checked = saved.notifications;
function values() { return cleanSettings({ engineUrl: $('engine-url').value, token: $('token').value, contextMenu: $('context-menu').checked, autoCapture: $('auto-capture').checked, notifications: $('notifications').checked }); }
async function openApp(e) { e?.preventDefault(); await chrome.tabs.create({ url: saved.engineUrl + '/app' }); }
['brand', 'open-app', 'back'].forEach(id => $(id).addEventListener('click', openApp));
$('reveal').addEventListener('click', () => { const hide = $('token').type === 'text'; $('token').type = hide ? 'password' : 'text'; $('reveal').setAttribute('aria-label', hide ? 'Show pairing token' : 'Hide pairing token'); });
function status(text, ok = false) { $('test-status').lastChild.textContent = text; $('test-status').classList.toggle('online', ok); }
async function grant(config) {
  // Call directly from the click/submit gesture so Chrome can show its permission UI.
  const granted = await chrome.permissions.request({ origins: [permissionOrigin(config.engineUrl)] });
  if (!granted) throw new Error('Engine access was not granted. Your previous connection remains saved.');
}
async function test(config) { const result = await send({ type: 'test', settings: config }); status('Connected', true); return result; }
$('test-connection').addEventListener('click', async () => {
  const button = $('test-connection');
  try { const config = values(); const permission = grant(config); button.disabled = true; message($('connection-notice'), 'Checking engine and pairing token…'); await permission; await test(config); message($('connection-notice'), 'Connection verified. Save to use it in Chrome.'); }
  catch (error) { status('Not connected'); message($('connection-notice'), error.message, true); }
  finally { button.disabled = false; }
});
$('connection-form').addEventListener('submit', async e => {
  e.preventDefault();
  try { const config = values(); const permission = grant(config); $('save').disabled = true; await permission; await test(config); await chrome.storage.local.set({ settings: config }); saved = config; message($('connection-notice'), 'Connection saved. Chrome is ready to send links to MK.'); }
  catch (error) { status('Not connected'); message($('connection-notice'), error.message, true); }
  finally { $('save').disabled = false; }
});
for (const [id, key, permission] of [['context-menu', 'contextMenu', null], ['auto-capture', 'autoCapture', 'downloads'], ['notifications', 'notifications', 'notifications']]) {
  $(id).addEventListener('change', async () => {
    const wanted = $(id).checked;
    try {
      if (wanted && permission && !(await chrome.permissions.request({ permissions: permission === 'downloads' ? ['downloads', 'alarms'] : [permission] }))) throw new Error('Permission was not granted. This feature remains off.');
      saved = { ...saved, [key]: wanted }; await chrome.storage.local.set({ settings: saved });
      message($('capture-notice'), key === 'autoCapture' && wanted ? 'Automatic capture enabled. Chrome keeps each download until MK receives data.' : 'Preference saved.');
    } catch (error) { $(id).checked = !wanted; message($('capture-notice'), error.message, true); }
  });
}
document.querySelectorAll('.side-nav a').forEach(link => link.addEventListener('click', () => { document.querySelectorAll('.side-nav a').forEach(a => a.classList.toggle('active', a === link)); }));
document.documentElement.dataset.ready = 'true';
if (saved.token) { try { await test(saved); } catch { status('Not connected'); } }
