export const DEFAULT_ENGINE = 'http://127.0.0.1:8976';
export const DEFAULT_SETTINGS = Object.freeze({ engineUrl: DEFAULT_ENGINE, token: '', contextMenu: true, autoCapture: false, notifications: false });
export function engineUrl(value = DEFAULT_ENGINE) {
  const url = new URL(value.trim());
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || !['', '/'].includes(url.pathname)) throw new Error('Use an HTTP or HTTPS engine address without a path, password, or query.');
  return url.origin;
}
export function downloadUrl(value) {
  if (typeof value !== 'string' || value.length > 8192) throw new Error('Enter a valid file link.');
  let url; try { url = new URL(value.trim()); } catch { throw new Error('Enter a complete HTTP or HTTPS file link.'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('Only HTTP and HTTPS file links without embedded passwords are supported.');
  url.hash = '';
  return url.href;
}
export function cleanSettings(value = {}) {
  const token = typeof value.token === 'string' ? value.token.trim() : '';
  if (token.length > 4096 || /[\r\n]/.test(token)) throw new Error('The pairing token is invalid.');
  return { engineUrl: engineUrl(value.engineUrl || DEFAULT_ENGINE), token, contextMenu: value.contextMenu !== false, autoCapture: value.autoCapture === true, notifications: value.notifications === true };
}
export function permissionOrigin(value) { const url = new URL(engineUrl(value)); return `${url.protocol}//${url.hostname}/*`; }
export function prepareDownload(payload) {
  if (!Array.isArray(payload.urls) || !payload.urls.length || payload.urls.length > 100) throw new Error('Add between 1 and 100 file links at a time.');
  const urls = [...new Set(payload.urls.map(downloadUrl))];
  const body = { urls };
  if (payload.connections !== undefined) {
    if (![1, 2, 4, 8, 16].includes(payload.connections)) throw new Error('Choose a supported connection count.');
    body.connections = payload.connections;
  }
  return body;
}
export function actionPath(id, action) {
  if (typeof id !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(id) || !['pause', 'resume', 'cancel', 'retry'].includes(action)) throw new Error('Invalid transfer action.');
  return `/api/downloads/${encodeURIComponent(id)}/${action}`;
}
export async function requestEngine(settings, path, { body, fetcher = fetch, timeout = 10000 } = {}) {
  if (!/^\/api\/(health|state|downloads(?:\/[a-zA-Z0-9_-]+\/(?:pause|resume|cancel|retry))?)$/.test(path)) throw new Error('Unsupported engine request.');
  const config = cleanSettings(settings);
  if (path !== '/api/health' && !config.token) throw new Error('Connect your engine in settings first.');
  const headers = { Accept: 'application/json' };
  if (config.token) headers.Authorization = `Bearer ${config.token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  let response;
  try {
    response = await fetcher(config.engineUrl + path, { method: body === undefined ? 'GET' : 'POST', headers, body: body === undefined ? undefined : JSON.stringify(body), credentials: 'omit', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(timeout) });
  } catch { throw new Error('Cannot reach MK Engine. Start the downloader and check your connection settings.'); }
  if (response.status === 401 || response.status === 403) throw new Error('Pairing token was rejected. Copy a new token from MK Downloader.');
  let data; try { data = await response.json(); } catch { throw new Error('The engine returned an unreadable response.'); }
  if (!response.ok) throw new Error(typeof data.error === 'string' ? data.error.slice(0, 200) : `Engine request failed (${response.status}).`);
  return data;
}
export function acceptedJobs(data) {
  if (!data || !Array.isArray(data.jobs) || !data.jobs.length || data.jobs.some(job => !job || typeof job.id !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(job.id))) throw new Error('MK Engine did not confirm the transfer. Your browser download is unchanged.');
  return data.jobs;
}
export function receivedBytes(job) { return Math.max(0, Number(job.downloadedBytes ?? job.receivedBytes ?? job.received ?? job.downloaded ?? job.bytesReceived ?? 0) || 0); }
export function totalBytes(job) { return Math.max(0, Number(job.totalBytes ?? job.size ?? job.total ?? 0) || 0); }
export function transferStarted(job) { return ['downloading', 'running', 'completed', 'complete'].includes(job?.status) && receivedBytes(job) > 0; }
export function formatBytes(value) {
  const n = Math.max(0, Number(value) || 0); if (n < 1024) return `${Math.round(n)} B`;
  const i = Math.min(4, Math.floor(Math.log(n) / Math.log(1024))); return `${(n / 1024 ** i).toFixed(i === 1 ? 0 : 1)} ${['B', 'KB', 'MB', 'GB', 'TB'][i]}`;
}
