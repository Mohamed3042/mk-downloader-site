# MK Downloader — Chrome Companion

The Manifest V3 companion sends links to the MK download engine. The engine must be running on your computer or an explicitly paired server. Downloads and partial files live on that engine, independently of the Chrome popup.

## Load in Chrome

1. Open the installed **MK Downloader** desktop app, or use the provided `START-MK-DOWNLOADER.cmd` source launcher. Keep it running.
2. Open `chrome://extensions` in desktop Chrome and turn on **Developer mode**.
3. Choose **Load unpacked** and select this directory. If using the ZIP, extract it first and select the folder containing `manifest.json`. The Windows installer also includes a `resources/chrome-extension` folder inside the application installation directory.
4. Pin **MK Downloader — Chrome Companion** to the toolbar.
5. Open the companion, choose the settings gear, and enter your engine address. The default is `http://127.0.0.1:8976`.
6. Copy the engine pairing token from **MK Downloader → Devices**. Choose **Test connection**, then **Save connection**.

For source-only use without the desktop app, build the application first, then run `npm run start:web` from the application folder. The console reports the local file containing its pairing token; read that file to pair Chrome. The standalone engine and desktop app use separate state folders. Run one engine at a time on port 8976.

This is an unpacked extension. It has not been submitted to the Chrome Web Store or installed into your personal Chrome profile by this project.

## Send and manage files

- Paste one HTTP/HTTPS file URL per line in **Add link**, choose the number of parallel connections, and press **Send to MK**.
- Right-click a file link, audio, or video and choose **Download with MK**.
- Choose **Page links** to inspect the current page's links, select the ones you want, and send them together. Discovery inspects only the page you explicitly activate; it does not crawl sites or monitor browsing history. It includes ordinary webpage URLs as well as direct file URLs, so select direct files where possible.
- The popup lists the three newest transfers with live progress and pause/resume/retry controls. **Open MK Downloader** opens the full `/app` dashboard.

The default queue is the engine's main queue. Filenames come from the download source. The extension does not claim that every page URL is a downloadable media file, and it does not bypass DRM or website sign-in. Authenticated sites may require Chrome's own downloader; no browser cookies are read or copied.

## Optional capture and notifications

Both features are off initially and request a separate Chrome permission when switched on.

Automatic capture sends new ordinary HTTP/HTTPS browser downloads to MK, while Chrome continues. It cancels the browser transfer only after the backend reports an active or completed transfer with **more than zero received bytes**. A queued acknowledgment, rejected token, offline engine, or malformed response cannot cancel Chrome. If Chrome finishes first or MK cannot begin within the handoff window, the queued duplicate in MK is cancelled when the companion can reach the engine. Incognito downloads, extension-initiated downloads, and downloads from the engine itself are excluded. Temporary overlapping traffic can occur during verification.

After handoff, a persisted record and a 30-second Chrome alarm monitor MK until completion. If MK reports failure, or becomes unreachable for more than 90 seconds, Chrome starts the original URL again using its own download handling. Cancelling a transfer in MK is respected and does not restart it. This recovery restarts that browser transfer; it does not splice MK's partial bytes. Chrome must be running for recovery. If the source URL has expired, add a fresh link. An unreachable MK engine may continue its own copy while Chrome recovers.

Turn on notifications to receive a native Chrome notice after handoff or when a link cannot be sent. A toolbar badge also records the last result.

## Permissions and privacy

- `storage`: saves the engine address, pairing token and preferences locally in this Chrome profile, not Chrome Sync.
- `contextMenus`: adds the explicit right-click command.
- `activeTab` and `scripting`: discover links on the page you choose through the popup.
- Loopback host access: communicates with the local engine. A different engine address requests access to that specific host only when you connect.
- Optional `downloads`: watches new downloads and safely hands off verified transfers only when you enable automatic capture.
- Optional `alarms`: checks handed-off transfers and restores Chrome fallback if MK fails later.
- Optional `notifications`: displays user-enabled transfer notices.

No analytics, remote scripts, cookie collection, history collection or third-party network calls are included. Keep pairing tokens private. Remote engine addresses should use HTTPS; HTTP is suitable only for a trusted local network. `localhost` on your phone means the phone itself; phone use is through MK's separate web app at your computer's reachable address.

Stable extension ID: `cbkiopdhgcpjaaelbefdnejkghmblpli`. The manifest includes a public identity key so the backend can allowlist this exact extension origin. No private signing key is shipped.

## Validation

From the app directory: `node --test tests/extension.test.mjs` and, when a Playwright Chromium executable is available, `node tests/extension-browser.mjs`.

UI concepts: `../../concepts/10-extension-popup.png` and `../../concepts/11-extension-settings.png`. Implementation follows the concept's navy/mint panels, type hierarchy and layout; labels reflect implemented backend capabilities.

