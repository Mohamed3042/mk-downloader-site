import { DEFAULT_SETTINGS, cleanSettings, downloadUrl, formatBytes, receivedBytes, totalBytes } from './core.mjs';
import { decorate, send, message, element, icon } from './ui.mjs';
decorate();
const $ = id => document.getElementById(id);
let config = DEFAULT_SETTINGS;
let lastJobs = [];
let polling = false;
async function openApp() { await chrome.tabs.create({ url: config.engineUrl + '/app' }); }
['open-app', 'view-all', 'brand'].forEach(id => $(id).addEventListener('click', e => { e.preventDefault(); void openApp(); }));
$('settings').addEventListener('click', () => chrome.runtime.openOptionsPage());
function connected(ok, label) { $('connection').classList.toggle('online', ok); $('connection-label').textContent = label; }
function jobRow(job) {
  const row = element('div', 'transfer-row');
  const file = element('div', 'file-symbol'); file.innerHTML = icon('file', 26); row.append(file);
  const body = element('div', 'transfer-body'); body.append(element('strong', 'filename', job.filename || job.name || 'Download'));
  const completed = ['completed', 'complete'].includes(job.status);
  const amount = receivedBytes(job), total = totalBytes(job);
  const percent = completed ? 100 : total ? Math.min(100, amount / total * 100) : 0;
  const bar = element('div', 'progress'); const fill = element('div'); fill.style.width = `${percent}%`; bar.append(fill); bar.setAttribute('role', 'progressbar'); bar.setAttribute('aria-valuenow', String(Math.round(percent))); bar.setAttribute('aria-label', 'Transfer progress'); body.append(bar);
  const caption = completed ? 'Completed' : `${formatBytes(amount)}${total ? ' / ' + formatBytes(total) : ''} · ${job.status || 'Queued'}`;
  body.append(element('small', '', caption)); row.append(body);
  if (completed) { const done = element('span', 'mint'); done.innerHTML = icon('check', 24); done.title = 'Completed'; row.append(done); }
  else {
    const action = ['failed', 'cancelled'].includes(job.status) ? 'retry' : job.status === 'paused' ? 'resume' : 'pause';
    const button = element('button', 'icon-button'); button.type = 'button'; button.innerHTML = icon(action === 'pause' ? 'pause' : action === 'retry' ? 'retry' : 'play', 24); button.title = `${action[0].toUpperCase() + action.slice(1)} ${job.filename || 'download'}`; button.setAttribute('aria-label', button.title);
    button.addEventListener('click', async () => { button.disabled = true; try { await send({ type: 'action', id: job.id, action }); await refresh(); } catch (error) { message($('notice'), error.message, true); } finally { button.disabled = false; } }); row.append(button);
  }
  return row;
}
async function refresh() {
  if (polling) return; polling = true;
  try {
    const state = await send({ type: 'state' });
    connected(true, 'Connected to MK Engine');
    lastJobs = Array.isArray(state.jobs) ? state.jobs : [];
    $('transfers').replaceChildren(...lastJobs.slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 3).map(jobRow));
    if (!lastJobs.length) $('transfers').append(element('div', 'empty', 'Your first transfer starts with a link.'));
  } catch (error) { connected(false, config.token ? 'Engine offline' : 'Connect your engine'); if (!lastJobs.length) $('transfers').replaceChildren(element('div', 'empty', error.message)); }
  finally { polling = false; }
}
async function submitUrls(urls, button) {
  button.disabled = true; message($('notice'), 'Sending to your engine…');
  try {
    const result = await send({ type: 'add', urls, connections: Number($('connections').value) });
    message($('notice'), `${result.jobs.length} ${result.jobs.length === 1 ? 'transfer added' : 'transfers added'}. Keep the engine running to download.`);
    await refresh(); return true;
  } catch (error) { message($('notice'), error.message, true); return false; }
  finally { button.disabled = false; }
}
$('add-panel').addEventListener('submit', async e => { e.preventDefault(); const urls = $('url').value.split(/\r?\n/).map(s => s.trim()).filter(Boolean); if (await submitUrls(urls, $('send'))) $('url').value = ''; });
function activate(tab) {
  const page = tab === 'page';
  for (const kind of ['add', 'page']) { const active = kind === tab; $(`tab-${kind}`).classList.toggle('active', active); $(`tab-${kind}`).setAttribute('aria-selected', String(active)); $(`${kind}-panel`).hidden = !active; }
  if (page) void discover();
}
$('tab-add').addEventListener('click', () => activate('add'));
$('tab-page').addEventListener('click', () => activate('page'));
document.querySelector('.tabs').addEventListener('keydown', e => { if (['ArrowLeft', 'ArrowRight'].includes(e.key)) { e.preventDefault(); const next = $('tab-add').classList.contains('active') ? 'page' : 'add'; activate(next); $(`tab-${next}`).focus(); } });
async function discover() {
  $('page-links').replaceChildren(element('div', 'empty', 'Reading this page’s links…')); $('send-selected').disabled = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:/.test(tab.url || '')) throw new Error('Open a regular website, then open the companion to find its links.');
    const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
      const links = [...document.querySelectorAll('a[href], video[src], audio[src], source[src]')].map(el => ({ url: el.href || el.src, label: el.textContent?.trim().slice(0, 100) || el.getAttribute('download') || '' }));
      return [{ url: location.href, label: document.title || 'Current page' }, ...links].slice(0, 500);
    } });
    const seen = new Set(); const links = [];
    for (const item of results[0]?.result || []) { try { const url = downloadUrl(item.url); if (seen.has(url)) continue; seen.add(url); links.push({ url, label: item.label || new URL(url).pathname.split('/').pop() || new URL(url).hostname }); } catch { /* Unsupported scheme. */ } if (links.length === 100) break; }
    $('page-links').replaceChildren();
    for (const item of links) {
      const row = element('label', 'link-row'); const check = element('input'); check.type = 'checkbox'; check.value = item.url; check.addEventListener('change', () => { $('send-selected').disabled = !$('page-links').querySelector('input:checked'); });
      const text = element('span'); text.append(element('strong', '', item.label), element('small', '', item.url)); row.append(check, text); $('page-links').append(row);
    }
    if (!links.length) $('page-links').append(element('div', 'empty', 'No HTTP file links found on this page.'));
  } catch (error) { $('page-links').replaceChildren(element('div', 'empty', error.message)); }
}
$('refresh-links').addEventListener('click', discover);
$('send-selected').addEventListener('click', async () => { const urls = [...$('page-links').querySelectorAll('input:checked')].map(el => el.value); if (await submitUrls(urls, $('send-selected'))) { $('page-links').querySelectorAll('input').forEach(el => { el.checked = false; }); $('send-selected').disabled = true; } });
const saved = await chrome.storage.local.get(['settings', 'lastNotice']);
config = cleanSettings({ ...DEFAULT_SETTINGS, ...saved.settings });
$('host-label').textContent = ['127.0.0.1', 'localhost', '[::1]'].includes(new URL(config.engineUrl).hostname) ? 'This computer' : new URL(config.engineUrl).host;
if (saved.lastNotice && Date.now() - saved.lastNotice.time < 60000) message($('notice'), saved.lastNotice.message, saved.lastNotice.failed);
await chrome.action.setBadgeText({ text: '' });
await refresh();
const timer = setInterval(refresh, 1800);
window.addEventListener('pagehide', () => clearInterval(timer));
