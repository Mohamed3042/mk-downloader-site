import { DEFAULT_SETTINGS, cleanSettings, permissionOrigin, prepareDownload, actionPath, requestEngine, acceptedJobs, downloadUrl, transferStarted } from './core.mjs';

const MENU = 'mk-download-link';
export async function settings() { const { settings: saved } = await chrome.storage.local.get('settings'); return cleanSettings({ ...DEFAULT_SETTINGS, ...saved }); }
async function permitted(config) {
  if (!(await chrome.permissions.contains({ origins: [permissionOrigin(config.engineUrl)] }))) throw new Error('Allow access to this engine address in connection settings.');
}
async function engine(path, options, config) { const current = config || await settings(); await permitted(current); return requestEngine(current, path, options); }
async function syncMenu() {
  try { await chrome.contextMenus.removeAll(); if ((await settings()).contextMenu) chrome.contextMenus.create({ id: MENU, title: 'Download with MK', contexts: ['link', 'audio', 'video'], targetUrlPatterns: ['http://*/*', 'https://*/*'] }); } catch { /* Chrome may be shutting down. */ }
}
async function note(message, failed = false) {
  await chrome.storage.local.set({ lastNotice: { message, failed, time: Date.now() } });
  await chrome.action.setBadgeText({ text: failed ? '!' : '✓' });
  await chrome.action.setBadgeBackgroundColor({ color: failed ? '#c55366' : '#197f76' });
  const config = await settings();
  if (config.notifications && await chrome.permissions.contains({ permissions: ['notifications'] })) await chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'MK Downloader', message });
}
async function add(payload) { const data = await engine('/api/downloads', { body: prepareDownload(payload) }); const jobs = acceptedJobs(data); await note(`${jobs.length} ${jobs.length === 1 ? 'transfer sent' : 'transfers sent'} to MK Engine.`); return { jobs }; }

export async function route(message, sender) {
  if (sender?.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL('')) || !message || typeof message.type !== 'string') throw new Error('Untrusted extension request.');
  switch (message.type) {
    case 'state': return engine('/api/state');
    case 'health': return engine('/api/health');
    case 'test': {
      const config = cleanSettings(message.settings); await permitted(config);
      const health = await engine('/api/health', undefined, config);
      if (health.ok !== true || typeof health.product !== 'string' || !/mk/i.test(health.product)) throw new Error('This address is not an MK download engine.');
      await engine('/api/state', undefined, config); return health;
    }
    case 'add': return add(message);
    case 'action': return engine(actionPath(message.id, message.action), { body: {} });
    default: throw new Error('Unknown extension request.');
  }
}
chrome.runtime.onMessage.addListener((message, sender, respond) => { route(message, sender).then(data => respond({ ok: true, data }), error => respond({ ok: false, error: error.message })); return true; });
chrome.runtime.onInstalled.addListener(syncMenu);
chrome.runtime.onStartup.addListener(syncMenu);
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.settings) syncMenu(); });
chrome.contextMenus.onClicked.addListener(async info => {
  if (info.menuItemId !== MENU) return;
  try { await add({ urls: [downloadUrl(info.linkUrl || info.srcUrl)] }); } catch (error) { await note(error.message, true); }
});

// Optional capture is fail-open. Chrome continues until MK has received actual bytes.
// The pending map lives in storage so MV3 worker suspension cannot lose ownership.
async function capture(item) {
  if (!(await settings()).autoCapture || item.byExtensionId || item.incognito || item.state !== 'in_progress' || !await chrome.permissions.contains({ permissions: ['downloads'] })) return;
  let url; try { url = downloadUrl(item.finalUrl || item.url); } catch { return; }
  const config = await settings();
  if (new URL(url).origin === config.engineUrl) return;
  try {
    const jobs = acceptedJobs(await engine('/api/downloads', { body: { urls: [url] } }));
    const key = `capture:${jobs[0].id}`;
    await chrome.storage.local.set({ [key]: { browserId: item.id, jobId: jobs[0].id, url, phase: 'pending', createdAt: Date.now(), lastSeenAt: Date.now() } });
    if (chrome.alarms) await chrome.alarms.create('mk-capture-reconcile', { periodInMinutes: 0.5 });
    // Bounded handoff check: queued acceptance alone never cancels Chrome.
    for (let attempt = 0; attempt < 25; attempt++) {
      await reconcileCaptures();
      const pending = (await chrome.storage.local.get(key))[key];
      if (!pending || pending.phase === 'handedOff') break;
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  } catch (error) { await note(`Chrome kept this download. ${error.message}`, true); }
}
let reconciling = false;
async function browserFallback(key, entry, browser) {
  // If Chrome still has a live original, simply preserve it. Otherwise restart with
  // Chrome's own credentials and download handling; byExtensionId prevents loops.
  if (!browser || browser.state !== 'in_progress') await chrome.downloads.download({ url: downloadUrl(entry.url), conflictAction: 'uniquify' });
  await chrome.storage.local.remove(key);
  await note('MK could not finish the transfer. Chrome is handling the download again.', true);
}
export async function reconcileCaptures() {
  if (reconciling) return; reconciling = true;
  try {
    const all = await chrome.storage.local.get(null);
    const pending = Object.entries(all).filter(([key]) => key.startsWith('capture:'));
    if (!pending.length) { if (chrome.alarms) await chrome.alarms.clear('mk-capture-reconcile'); return; }
    const config = await settings();
    let state;
    try { state = await engine('/api/state'); }
    catch {
      for (const [key, entry] of pending) {
        if (entry.phase === 'handedOff' && Date.now() - entry.lastSeenAt > 90000) {
          const browser = (await chrome.downloads.search({ id: entry.browserId }))[0];
          await browserFallback(key, entry, browser);
        }
      }
      return;
    }
    for (const [key, entry] of pending) {
      const job = state.jobs?.find(job => job.id === entry.jobId);
      const browser = (await chrome.downloads.search({ id: entry.browserId }))[0];
      if (entry.phase === 'handedOff') {
        if (['cancelled', 'canceled'].includes(job?.status)) { await chrome.storage.local.remove(key); continue; }
        if (browser?.state === 'complete') { if (job && !['completed', 'complete', 'cancelled', 'canceled'].includes(job.status)) await engine(actionPath(job.id, 'cancel'), { body: {} }).catch(() => {}); await chrome.storage.local.remove(key); continue; }
        if (['completed', 'complete'].includes(job?.status)) { if (browser?.state === 'in_progress') await chrome.downloads.cancel(entry.browserId); await chrome.storage.local.remove(key); continue; }
        if (!config.autoCapture || !job || ['failed', 'error'].includes(job.status)) {
          if (job && !['cancelled', 'canceled', 'failed'].includes(job.status)) await engine(actionPath(job.id, 'cancel'), { body: {} }).catch(() => {});
          await browserFallback(key, entry, browser); continue;
        }
        if (browser?.state === 'in_progress' && transferStarted(job)) await chrome.downloads.cancel(entry.browserId);
        await chrome.storage.local.set({ [key]: { ...entry, lastSeenAt: Date.now() } });
        continue;
      }
      const expired = Date.now() - entry.createdAt > 30000;
      if (!config.autoCapture || !browser || browser.state !== 'in_progress' || expired || !job || ['failed', 'cancelled', 'canceled', 'error'].includes(job.status)) {
        // A queued/failed transfer cannot replace a browser download. Cancel only our duplicate.
        if (job && !['completed', 'complete', 'cancelled', 'canceled'].includes(job.status)) await engine(actionPath(job.id, 'cancel'), { body: {} }).catch(() => {});
        await chrome.storage.local.remove(key); continue;
      }
      if (transferStarted(job)) {
        // Save ownership before cancelling Chrome so a worker restart can recover.
        await chrome.storage.local.set({ [key]: { ...entry, phase: 'handedOff', lastSeenAt: Date.now() } });
        await chrome.downloads.cancel(entry.browserId);
        await note('MK Engine received data. The transfer is now handled by MK.');
      }
    }
  } catch { /* The browser transfer remains untouched on connection/auth failures. */ }
  finally { reconciling = false; }
}
let captureListeners = false;
let alarmListener = false;
function installCaptureListeners() {
  if (!alarmListener && chrome.alarms?.onAlarm) { chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'mk-capture-reconcile') void reconcileCaptures(); }); alarmListener = true; }
  if (captureListeners || !chrome.downloads?.onCreated) return;
  chrome.downloads.onCreated.addListener(capture);
  chrome.downloads.onChanged.addListener(reconcileCaptures);
  captureListeners = true;
}
installCaptureListeners();
chrome.permissions.onAdded.addListener(installCaptureListeners);
chrome.permissions.onRemoved.addListener(async permissions => { if (permissions.permissions?.includes('downloads')) await chrome.storage.local.set({ settings: { ...await settings(), autoCapture: false } }); });
chrome.runtime.onStartup.addListener(reconcileCaptures);
// State polling from the popup also advances capture checks, without keeping the worker alive.
chrome.runtime.onMessage.addListener((message, sender) => { if (sender?.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL('')) && message?.type === 'state') void reconcileCaptures(); });
